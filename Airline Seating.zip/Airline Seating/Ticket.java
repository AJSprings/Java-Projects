
public class Ticket {
	
	int ticketType;
	
	String seatPref;
	
	public int getTicketType() {
		return ticketType;
	}
	
	public void setTicketType(int type) {
		this.ticketType = type;
	}
	
	public String getSeatPref() {
		return seatPref;
	}
	
	public void setSeatPref(String pref) {
		this.seatPref = pref;
	}
}
