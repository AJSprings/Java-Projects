
import java.util.Scanner;
public class Airplane {
	
	
	public static void main(String[] args) {
		
		char firstClassSeats[]=new char[20];
		
		char economyClassSeats[]=new char[90];
		initialize(firstClassSeats,economyClassSeats);
		int n1=0;
		int n2=0;
		while(true)
		{
		/*
		three commands: add passengers,
		show seating and quit.
		*/
		System.out.println("1. Add passengers");
		System.out.println("2. Show seating");
		System.out.println("3. Quit");
		System.out.println("Enter your choice: ");
		Scanner scan=new Scanner(System.in);
		int choice=scan.nextInt();
		switch(choice)
		{
		case 1: addPassengers(firstClassSeats,economyClassSeats,n1, n2);
		break;
		case 2: showSeating(firstClassSeats,economyClassSeats);
		break;
		case 3: System.exit(0);
		}
		}
		  

		}
	
	
		private static void addPassengers(char[] firstClassSeats, char[] economyClassSeats, int n1, int n2)
		{
		System.out.println("Enter the class <first or economy>: ");
		Scanner scan=new Scanner(System.in);
		String className=scan.next();
		int numPassengers=0;
		String preference="";
		boolean match=false;
		if(className.equalsIgnoreCase("first"))
		{
		System.out.println("Enter the number of passengers traveling together <1 or 2>: ");
		numPassengers=scan.nextInt();
		System.out.println("Enter the seating preferences <aisle or window>: ");
		preference=scan.next();
		if((n1+numPassengers)<20)
		{
		if(numPassengers==1 && preference.equalsIgnoreCase("aisle"))
		{
		firstClassSeats[n1+numPassengers]='A'; // allocated
		match=true;
		}
		else if(numPassengers==2)
		{
		firstClassSeats[n1+1]='A'; // allocated
		firstClassSeats[n1+2]='A';
		match=true;
		}
		}
		else if(((n2+numPassengers)<90) && !((n1+numPassengers)<20))
		{
			System.out.println("First class doesn't have enough seats left, but Economy class has enough seats");
		}
		
		else if(!((n2+numPassengers)<90) && !((n1+numPassengers)<20)) 
		{
			System.out.println("Sorry, plane is full.");
		}
		
		
		}
		else if(className.equalsIgnoreCase("economy"))
		{
		System.out.println("Enter the number of passengers traveling together <1 or 2 or 3>: ");
		numPassengers=scan.nextInt();
		System.out.println("Enter the seating preferences <center or window>: ");
		preference=scan.nextLine();
		if((n2+numPassengers)<90)
		{
		if(numPassengers==1 && (n2+numPassengers)%2!=0 && preference.equalsIgnoreCase("center"))
		{
		economyClassSeats[n2+1]='A'; // allocated
		match=true;
		}
		else if(numPassengers==2)
		{
		economyClassSeats[n2+1]='A'; // allocated
		economyClassSeats[n2+2]='A';
		match=true;
		}
		else if(numPassengers==3)
		{
		economyClassSeats[n2+1]='A'; // allocated
		economyClassSeats[n2+2]='A';
		economyClassSeats[n2+3]='A';
		match=true;
		}
		}
		else if(!((n2+numPassengers)<90) && (n1+numPassengers)<20)
		{
			System.out.println("Economy class doesn't have enough seats left, but first class has enough seats");
		}
		
		else if(!((n2+numPassengers)<90) && !((n1+numPassengers)<20)) 
		{
			System.out.println("Sorry, plane is full.");
		}
		
		}
		if(match==false)
		{
		System.out.println(" No match exists");
		}
		}
		/*
		shows seating arrangement and seats currently allocated
		*/
		private static void showSeating(char[] firstClassSeats, char[] economyClassSeats) {
		System.out.println("Seating arrangement");
		for(int i=0;i<20;i++)
		{
		System.out.print(firstClassSeats[i]+" ");
		if(i%4==0)
		System.out.println("");
		}
		System.out.println("\n");
		for(int i=0;i<90;i++)
		{
		System.out.print(economyClassSeats[i]+" ");
		if(i%6==0)
		System.out.println("");
		}
		}

		private static void initialize(char[] firstClassSeats, char[] economyClassSeats) {
		for(int i=0;i<20;i++)
		{
		firstClassSeats[i]='_';
		}
		for(int i=0;i<90;i++)
		{
		economyClassSeats[i]='_';
		}
		}
	
	}

