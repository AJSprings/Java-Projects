
public class Passenger {
	
	String name;
	
	
	
	
	

}
